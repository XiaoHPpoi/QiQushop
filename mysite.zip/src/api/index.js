import req from "./req";
export const reqImg = () => {
    return req.get("/ACG?api_key=0256c0a198846f7c&type=json&size=square")
} 