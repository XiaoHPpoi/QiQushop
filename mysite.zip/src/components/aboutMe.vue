<template>
    <div class="MyStyle">
        <div style="border-left:2px dashed #ffcc22;border-right:2px dashed #ffcc22;border-bottom:4px solid #ffcc22;">
            <img border="0" src="../assets/002.jpg" width="150" height="128">
            <p>账号: abc</p>
            <p>性别: 男</p>
            <p>手机号: 123456789</p>
            <p>我的收货地址: xxxxxxx</p>
        </div>
    </div>
</template>
<style>
.MyStyle{color: #686262;}
.MyStyle img {float:left;margin:0 50px 0 20%}
</style>