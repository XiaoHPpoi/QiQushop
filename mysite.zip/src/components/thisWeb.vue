<template>
    <div class="WebStyle">
        <div>
            <ul>
                <li>
                    <img border="0" src="../assets/002.jpg" width="150" height="128"><span class="say">这是一个普通的大学小组作业</span>
                </li>
                <li>
                    <p>小组成员：严伟源 邹凯威 刘凯霖</p>
                </li>
            </ul>
        </div>
        
    </div>
</template>
<style>
.WebStyle img {margin:10px 0 -10px 0}
.WebStyle ul li{list-style: none;}
.WebStyle div{
    display:flex;
    border-left:2px dashed #ffcc22;
    border-right:2px dashed #ffcc22;
    border-bottom:4px dashed #ffcc22;
}
.WebStyle div .say{
    font-size:50px;
    line-height: 150px;
    color: #000;
}
</style>